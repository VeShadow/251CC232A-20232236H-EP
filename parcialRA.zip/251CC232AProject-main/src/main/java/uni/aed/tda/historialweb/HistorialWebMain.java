/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uni.aed.tda.historialweb;
import java.util.Scanner;
import uni.aed.tda.ArrayListTDA.ArrayListTDA;
import uni.aed.tda.LinkedListTDA.LinkedListTDA;
import uni.aed.tda.ListTDA.ListTDA;

public class HistorialWebMain {
    public static void main(String[] args){
        HistorialWebMain hwm = new HistorialWebMain();
        hwm.pc2();
    }  
    
    private void pc2(){
        Scanner scr = new Scanner(System.in).useDelimiter("\n");
        System.out.print("LISTS\n1. ArrayListTDA\n2. LinkedListTDA\nQue tipo de estructura desea usar: ");
        int opcion = scr.nextInt();
        if(opcion == 1){
            opcionArrayListTDA(scr);
        } else {
            opcionLikedListTDA(scr);
        }
        scr.close();
    }
    
    // Menu si se usa ArrayListTDA
    private void opcionArrayListTDA(Scanner scr){
        boolean seguir = true;
        ListTDA<PaginaWeb> historial = new ArrayListTDA<>();
        while(seguir){
            System.out.print("MENU\n1. Agregar pagina web al historial\n2. Eliminar una URL especifica del historial\n3. Buscar si una URL fue visitada\n4. Agregar nueva visita antes/despues de una URL existente\n5. Visualizar historial en orden cronologica\n6. Salir\nIngrese una opcion: ");
            int opcion = scr.nextInt();            
            switch (opcion){
                case 1 -> {                                                     
                    agregarPaginaWeb(historial, scr);
                    visualizar(historial);
                    break;
                }
                case 2 -> {   
                    eliminarURL(historial, scr);
                    visualizar(historial);
                    break;
                }
                case 3 -> {                    
                    buscarURL(historial, scr);
                    break;
                }
                case 4 -> {
                    agregarAO(historial, scr);
                    visualizar(historial);
                    break;
                }
                case 5 -> {
                    
                    break;  
                }
                default -> {
                    seguir = false;
                }
            }
        }
    }
    
    // Menu si se usa LinkedListTDA
    private void opcionLikedListTDA(Scanner scr){
        boolean seguir = true;
        ListTDA<PaginaWeb> historial = new LinkedListTDA<>();
        while(seguir){
            System.out.print("MENU\n1. Agregar pagina web al historial\n2. Eliminar una URL especifica del historial\n3. Buscar si una URL fue visitada\n4. Agregar nueva visita antes/despues de una URL existente\n5. Visualizar historial en orden cronologica\n6. Salir\nIngrese una opcion: ");
            int opcion = scr.nextInt();            
            switch (opcion){
                case 1 -> {                                                     
                    agregarPaginaWeb(historial, scr);
                    visualizar(historial);
                    break;
                }
                case 2 -> {   
                    eliminarURL(historial, scr);
                    visualizar(historial);
                    break;
                }
                case 3 -> {                    
                    buscarURL(historial, scr);
                    break;
                }
                case 4 -> {
                    agregarAO(historial, scr);
                    visualizar(historial);
                    break;
                }
                case 5 -> {
                    visualizar(historial);
                    break;  
                }
                default -> {
                    seguir = false;
                }
            }
        }
    }
    
    private void agregarPaginaWeb(ListTDA<PaginaWeb> historial,Scanner scr){
        System.out.print("Introduzca la URL de la pagina web: ");
        PaginaWeb PagWeb = new PaginaWeb (scr.next());
        historial.add(PagWeb);
    }
    
    private void visualizar(ListTDA<PaginaWeb> historial){
        System.out.println("LISTA: " + historial);
    }
    
    private void eliminarURL(ListTDA<PaginaWeb> historial,Scanner scr){
        System.out.print("Introduzca la URL a eliminar: ");
        PaginaWeb PagWeb = new PaginaWeb (scr.next());
        historial.delete(PagWeb);
    }
    
    private void buscarURL(ListTDA<PaginaWeb> historial,Scanner scr){
        System.out.print("Introduzca la URL a buscar: ");
        PaginaWeb PagWeb = new PaginaWeb (scr.next());
        boolean existe = historial.contain(PagWeb);
        if (existe == false){
            System.out.println("La URL no fue visitada.");
        } else {
            System.out.println("La URL fue visitada.");
        }
    }
    
    private void agregarAO(ListTDA<PaginaWeb> historial,Scanner scr){
        System.out.print("Introduzca la URL de referencia: ");
        int index = historial.indexOf(new PaginaWeb(scr.next()));
        if(index == -1){
            System.out.println("URL de referencia no encontrada");
        } else {
            System.out.print("Agregar antes(1) o despues(2): ");
            int opcion = scr.nextInt();
            if(opcion == 1){
                System.out.print("Introduzca la URL a agregar: ");
                if(index == 0){
                    historial.add(index, new PaginaWeb(scr.next()));
                }else {
                    historial.add(index - 1, new PaginaWeb(scr.next()));
                }
            } else {
                System.out.print("Introduzca la URL a agregar: ");
                historial.add(index + 1, new PaginaWeb(scr.next()));    
            }
        }
    }
}
