/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uni.aed.tda.historialweb;

public class PaginaWeb{
    private String url;
    
    public PaginaWeb(String url){
        this.url = url;
    }
    
    public void setURL(String url){
        this.url = url;
    }
    
    public String getURL(){
        return url;
    }
    
    @Override
    public String toString(){
        return getURL();
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        PaginaWeb that = (PaginaWeb) obj;
        return url.equals(that.url);
    }
}
