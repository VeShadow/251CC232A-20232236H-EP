package uni.aed.tda;

public interface ContenedorMagico<T> {
    public T get();
    public void set(T contenido);    
}
